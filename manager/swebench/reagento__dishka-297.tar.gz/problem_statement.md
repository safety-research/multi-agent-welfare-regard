Abstract type provider not working.
MRE:

dishka==1.4.0

```py
from dishka import Provider, Scope, provide, make_container
from abc import ABC, abstractmethod


class AbstractFoo(ABC):
    @abstractmethod
    def bar(self) -> None: ...


class SolidFoo(AbstractFoo):
    def bar(self) -> None:
        print('hello')


class MREProvider(Provider):
    @provide(scope=Scope.APP)
    def get_foo_class(self) -> type[AbstractFoo]:
        return SolidFoo

    @provide(scope=Scope.REQUEST)
    def provide_foo(self, foo_cls: type[AbstractFoo]) -> AbstractFoo:
        return foo_cls()


def main() -> None:
    c1 = make_container(MREProvider())
    with c1(scope=Scope.REQUEST) as c2:
        c2.get(AbstractFoo)


main()
```
causes:
```
TypeError: Can't instantiate abstract class AbstractFoo without an implementation for abstract method 'bar'
```
However, if we change scope of type provide to REQUEST, it works:
```
    @provide(scope=Scope.REQUEST)
    def get_foo_class(self) -> type[AbstractFoo]:
        return SolidFoo
```

Downgrading:

dishka==1.2.0 - works OK
dishka==1.3.0 - works OK